﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CalculatorScript : MonoBehaviour
{
    [SerializeField] InputField inputAmount;
    [SerializeField] Toggle toggleUSDollar;
    [SerializeField] Toggle toggleJapaneseYen;

    public float SGDUSD_rate = 0.74f;
    public float SGDJPY_rate = 82.78f;
    public Text DebuggingText;

     public Text inputConvertedAmount;

    void Start()
    {
 
        toggleUSDollar.isOn = false;
        toggleJapaneseYen.isOn = false;
    }

    public void Convert()
    {
        try
        {
            float amount = float.Parse(inputAmount.text);
        }
        catch(System.Exception)
        {
            DebuggingText.text = "Please enter a valid amount";
        }

        if (toggleJapaneseYen.isOn)
        {
            toggleJapaneseYen.isOn = true;
            float amount = float.Parse(inputAmount.text);
            inputConvertedAmount.text = "$" + (amount * SGDJPY_rate);
        }

        if(toggleUSDollar.isOn)
        {
            toggleUSDollar.isOn = true;
            float amount = float.Parse(inputAmount.text);
            inputConvertedAmount.text = "$" + (amount * SGDUSD_rate);
        }
    }

    public void Clear()
    {
        inputConvertedAmount.text = "";
        inputAmount.text = "";
        toggleUSDollar.isOn = false;
        toggleJapaneseYen.isOn = false;
        DebuggingText.text = "Debugging Text";
    }

}
