﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CalculatorScript : MonoBehaviour
{
    [SerializeField] InputField inputAmount;
    [SerializeField] Toggle toggleUSDollar, ToggleMalaysianRM, ToggleEuropeanEUR;
    [SerializeField] Toggle toggleJapaneseYen, ToggleKoreanKRW, ToggleTaiwanTWD;

    public float SGDUSD_rate = 0.74f;
    public float SGDJPY_rate = 82.78f;
    public float SGDRM_rate = 3.08f;
    public float SGDEUR_rate = 0.63f;
    public float SGDKRW_rate = 881.54f;
    public float SGDTWD_rate = 20.73f;

    public Text DebuggingText;

     public Text inputConvertedAmount;

    void Start()
    {
 
        toggleUSDollar.isOn = false;
        toggleJapaneseYen.isOn = false;
    }

    public void Convert()
    {
        try
        {
            float amount = float.Parse(inputAmount.text);
        }
        catch(System.Exception)
        {
            DebuggingText.text = "Please enter a valid amount";
        }

        if (toggleJapaneseYen.isOn)
        {
            toggleJapaneseYen.isOn = true;
            float amount = float.Parse(inputAmount.text);
            inputConvertedAmount.text = "¥" + (amount * SGDJPY_rate);
        }

        if(toggleUSDollar.isOn)
        {
            toggleUSDollar.isOn = true;
            float amount = float.Parse(inputAmount.text);
            inputConvertedAmount.text = "$" + (amount * SGDUSD_rate);
        }

        if (ToggleKoreanKRW.isOn)
        {
            ToggleKoreanKRW.isOn = true;
            float amount = float.Parse(inputAmount.text);
            inputConvertedAmount.text = "$" + (amount * SGDKRW_rate);
        }

        if (ToggleMalaysianRM.isOn)
        {
            ToggleMalaysianRM.isOn = true;
            float amount = float.Parse(inputAmount.text);
            inputConvertedAmount.text = "RM" + (amount * SGDRM_rate);
        }

        if (ToggleTaiwanTWD.isOn)
        {
            ToggleTaiwanTWD.isOn = true;
            float amount = float.Parse(inputAmount.text);
            inputConvertedAmount.text = "$" + (amount * SGDTWD_rate);
        }

        if (ToggleEuropeanEUR.isOn)
        {
            ToggleEuropeanEUR.isOn = true;
            float amount = float.Parse(inputAmount.text);
            inputConvertedAmount.text = "€" + (amount * SGDEUR_rate);
        }
    }

    public void Clear()
    {
        inputConvertedAmount.text = "";
        inputAmount.text = "";
        toggleUSDollar.isOn = false;
        toggleJapaneseYen.isOn = false;
        DebuggingText.text = "Debugging Text";
    }

}
